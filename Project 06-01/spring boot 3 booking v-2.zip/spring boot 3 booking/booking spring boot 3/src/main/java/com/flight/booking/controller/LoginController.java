package com.flight.booking.controller;

import java.security.Principal;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.flight.booking.dto.AuthRequest;
import com.flight.booking.dto.AuthResponse;
import com.flight.booking.entity.Flight;
import com.flight.booking.entity.User;
import com.flight.booking.service.APIUtil;
import com.flight.booking.service.AuthService;

import jakarta.validation.Valid;

@Controller
public class LoginController {
	
	@Autowired
	private AuthService authService;
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)    
    public String login() {
        return "login";
    }		

	@RequestMapping(value = "/logoutuser", method = RequestMethod.GET)    
    public String logout() {
		System.out.println("Logout..............................");
		authService.logout();
        return "login";
    }	

	@RequestMapping(value = "/login", method = RequestMethod.POST)    
    public ModelAndView auth(@ModelAttribute("user") AuthRequest user, Model model) {	
				

	    ModelAndView modelAndView = new ModelAndView("/login");
	    modelAndView.addObject("message", "Invalid Credentials!");
	    
		try {
			RestTemplate restTemplate = new RestTemplate();

			String resourceUrl = "http://localhost:8080/api/v1/authenticate";

			HttpEntity<AuthRequest> request = new HttpEntity<AuthRequest>(user);

			ResponseEntity<AuthResponse> res = restTemplate.exchange(resourceUrl, HttpMethod.POST, request, AuthResponse.class);

			AuthResponse authResponse = res.getBody();		
			
			if(authResponse.getStatusCode() != HttpStatus.OK) {				
				return modelAndView;
			}else {		
				
				System.out.println("========================");
				System.out.println(authService.getRole());
				System.out.println("========================");
				
				authService.save(user.getUsername(), user.getPassword(), authResponse.getToken());
				
				if(authService.getRole().equals("Admin"))				
					return new ModelAndView("redirect:" + "/admin/users");
				else if(authService.getRole().equals("Traveller"))
					return new ModelAndView("redirect:" + "/traveller/index");
				else
					return modelAndView;
			}
		} catch (RestClientException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return modelAndView;
		}
    }
	
	@RequestMapping(value = "/success", method = RequestMethod.GET)    
	public String success(Model model) {
		
		String username = authService.getUsername();
		String password = authService.getPassword();
		String token = authService.getToken();
		
		model.addAttribute("username", username);
		model.addAttribute("password", password);
		model.addAttribute("token", token);
		
		return "success"; 		
	}
	

	
	
}