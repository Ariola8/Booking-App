package com.flight.booking.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.flight.booking.entity.User; 
 

public interface UserDao extends JpaRepository<User, Long>{
	
	public List<User> findByEmailContaining(String email);

	@Query(
			  value = "SELECT * FROM flight_user u WHERE u.user_id = ?1", 
			  nativeQuery = true)
	public List<Long> findUserBookings(Long userId);
	
	@Query(
			value="delete from flight_user u where u.flight_id=:flightId AND u.user_id=:userId",
			nativeQuery = true
			)
	public void deleteFromFlightUserTable(@Param("flightId") Long flightId, @Param("userId") Long userId);
	
	Optional<User> findByEmail(String email);
	Optional<User> findByFirstName(String name);	
//	Optional<User> findByUsername(String name);	
}
