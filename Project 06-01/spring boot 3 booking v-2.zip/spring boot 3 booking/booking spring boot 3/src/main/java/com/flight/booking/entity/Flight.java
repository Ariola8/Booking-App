package com.flight.booking.entity;
 
import java.util.Set;
 
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.persistence.JoinColumn;
import java.util.HashSet; 
 


@Entity 
public class Flight {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	private long id;
	 

	@NotBlank(message = "Airline Code is mandatory.")	
	private String airlineCode;

	@NotBlank(message = "Flight Number is mandatory.")
	@Size(min = 3, max = 3, message="Only 3 numbers allowed.")
	private String flightNumber;

	@NotBlank(message = "Origin is mandatory.")
	private String origin;

	@NotBlank(message = "Destination is mandatory.")
	private String destination;

	@NotBlank(message = "Flight Date is mandatory.")
	private String flightDate;

	@NotBlank(message = "Departure Time is mandatory.")
	private String departureTime;
 
	@Column(nullable = true)
	private String aircraftType;
 
	@Column(columnDefinition="Decimal(10,2) default '0'")
	private Integer economyClassSeats = 0;
 
	@Column(columnDefinition="Decimal(10,2) default '0'")
	private Integer premiumEconomyClassSeats = 0;
 
	@Column(columnDefinition="Decimal(10,2) default '0'")
	private Integer businessClassSeats = 0;
 
	@Column(columnDefinition="Decimal(10,2) default '0'")
	private Integer firstClassSeats = 0;
	

	@ManyToMany
	@JoinTable(
			name="flight_user",
			joinColumns = @JoinColumn(name="flight_id"),
			inverseJoinColumns = @JoinColumn(name="user_id")
			)	
	private Set<User> bookings = new HashSet<>();
	
	
		
	public Set<User> getBookings() {
		return bookings;
	}

	public void setBookings(Set<User> bookings) {
		this.bookings = bookings;
	}

	
	
	public Flight(long id, @NotBlank(message = "Airline Code is mandatory.") String airlineCode,
			@NotBlank(message = "Flight Number is mandatory.") @Size(min = 3, max = 3, message = "Only 3 numbers allowed.") String flightNumber,
			@NotBlank(message = "Origin is mandatory.") String origin,
			@NotBlank(message = "Destination is mandatory.") String destination,
			@NotBlank(message = "Flight Date is mandatory.") String flightDate,
			@NotBlank(message = "Departure Time is mandatory.") String departureTime, String aircraftType,
			Integer economyClassSeats, Integer premiumEconomyClassSeats, Integer businessClassSeats,
			Integer firstClassSeats, Set<User> bookings) {
		super();
		this.id = id;
		this.airlineCode = airlineCode;
		this.flightNumber = flightNumber;
		this.origin = origin;
		this.destination = destination;
		this.flightDate = flightDate;
		this.departureTime = departureTime;
		this.aircraftType = aircraftType;
		this.economyClassSeats = (economyClassSeats ==  null ? economyClassSeats : 0);
		this.premiumEconomyClassSeats = (premiumEconomyClassSeats ==  null ? premiumEconomyClassSeats : 0);
		this.businessClassSeats = (businessClassSeats ==  null ? businessClassSeats : 0);
		this.firstClassSeats = (firstClassSeats ==  null ? firstClassSeats : 0);
		this.bookings = bookings;
	}

	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAirlineCode() {
		return airlineCode;
	}
	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getFlightDate() {
		return flightDate;
	}
	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	public String getAircraftType() {
		return aircraftType;
	}
	public void setAircraftType(String aircraftType) {
		this.aircraftType = aircraftType;
	}
	public Integer getEconomyClassSeats() {
		return economyClassSeats;
	}
	public void setEconomyClassSeats(Integer economyClassSeats) {
		this.economyClassSeats = economyClassSeats;
	}
	public Integer getPremiumEconomyClassSeats() {
		return premiumEconomyClassSeats;
	}
	public void setPremiumEconomyClassSeats(Integer premiumEconomyClassSeats) {
		this.premiumEconomyClassSeats = premiumEconomyClassSeats;
	}
	public Integer getBusinessClassSeats() {
		return businessClassSeats;
	}
	public void setBusinessClassSeats(Integer businessClassSeats) {
		this.businessClassSeats = businessClassSeats;
	}
	public Integer getFirstClassSeats() {
		return firstClassSeats;
	}
	public void setFirstClassSeats(Integer firstClassSeats) {
		this.firstClassSeats = firstClassSeats;
	}
	
	public Integer getTotalSeats() {
		return this.businessClassSeats + this.economyClassSeats + this.premiumEconomyClassSeats + this.firstClassSeats;
	}
 
 
 
 
	
	
	
}
