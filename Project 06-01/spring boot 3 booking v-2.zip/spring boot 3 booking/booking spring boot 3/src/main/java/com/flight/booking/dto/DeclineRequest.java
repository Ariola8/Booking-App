package com.flight.booking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeclineRequest {

	private String reason;
	private String flightId;
	private String userId;
	
	
	
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public DeclineRequest(String reason, String flightId, String userId) {
		super();
		this.reason = reason;
		this.flightId = flightId;
		this.userId = userId;
	}
	public DeclineRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
