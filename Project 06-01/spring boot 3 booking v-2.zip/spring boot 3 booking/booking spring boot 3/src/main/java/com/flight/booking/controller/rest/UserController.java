package com.flight.booking.controller.rest;

import java.util.List;
import java.util.Set;

import java.util.HashSet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.booking.entity.Flight;
import com.flight.booking.entity.User;
import com.flight.booking.service.FlightService;
import com.flight.booking.service.UserService;
 

@RestController
@RequestMapping("/api/v1")
public class UserController {
	
	@Autowired
	private UserService userService;

	@Autowired
	private FlightService flightService;
	
	
	@GetMapping("/users")
	public List<User> getUsers(Model model)
	{
		 return userService.getUsers();
	}
	
	@GetMapping("/users/{userId}")
	public User getUser(@PathVariable String userId)
	{
		return userService.getUser(Long.parseLong(userId));
	}
	
	
	@PostMapping("/users")
	public ResponseEntity<User> addUser(@RequestBody User user)
	{		
		try {
			User res = userService.addUser(user);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(user, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

	@PutMapping("/users")
	public ResponseEntity<User> updateUser(@RequestBody User user)
	{
		try {
			User res = userService.updateUser(user); 
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) { 
			e.printStackTrace();
			return new ResponseEntity<>(user, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

	@DeleteMapping("/users/{userId}")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable String userId)
	{
		try {
			userService.deleteUser(Long.parseLong(userId));
			return new ResponseEntity<>(HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}
	

	@GetMapping("/users/email/{email}")
	public List<User> getUsersByEmail(@PathVariable String email)
	{
		 return userService.findByEmailContaining(email);
	}
	

	@GetMapping("/users/{userId}/bookings")
	public Set<Flight> getUsersBookings(@PathVariable String userId)
	{
		List<Long> flightsList = userService.getUserBookings(userId);
		Set<Flight> flights = new HashSet<Flight>();

		for(Long flightId: flightsList) {
	        flights.add(flightService.getFlight(flightId));
	    }

				
		return flights; 
	}
	
	
	
}
