package com.flight.booking.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flight.booking.entity.Flight;

public interface FlightDao extends JpaRepository<Flight, Long>{

}
