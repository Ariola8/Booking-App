package com.flight.booking.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.flight.booking.dto.DeclineRequest;
import com.flight.booking.entity.CancelBooking;
import com.flight.booking.entity.Flight;
import com.flight.booking.entity.User;
import com.flight.booking.service.APIUtil;
import com.flight.booking.service.AuthService;

import jakarta.validation.Valid;

@Controller
public class CancelBookingController {


	private static final String LOGIN_HTML = "login.html";
	private static final String TRAVELLER_FLIGHTS_SHOW_HTML = "traveller/flights/show.html";
	private static final String TRAVELLER_FLIGHTS_INDEX_HTML = "traveller/flights/index.html";
	private static final String TRAVELLER_INDEX_HTML = "traveller/index.html";
	private static final String REQUESTS_INDEX_HTML = "admin/requests/index.html";
	private static final String DECLINE_HTML = "admin/requests/decline.html";

	@Autowired
	private AuthService authService;
	
	private RestTemplate restTemplate ;

	private HttpHeaders headers;	
	
	CancelBookingController()
	{
		restTemplate = new RestTemplate();	
		headers = new HttpHeaders();
	}
	
	
	@RequestMapping(value = "/traveller/flights/{flightId}/request/cancel", method = RequestMethod.GET)
	public ModelAndView cancelBookingRequest(Model model, @PathVariable String flightId)
	{
		if (!authService.isTraveller()) {
			return new ModelAndView("redirect:" + "/login");
		}
		
		headers.setBearerAuth(authService.getToken());
		
		model.addAttribute("username", authService.getUsername());
		
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		String userId = Long.toString(authService.getId());
		 
		ResponseEntity<String> response = restTemplate.exchange(APIUtil.BOOKING_CANCEL_REQUEST(flightId, userId), HttpMethod.GET, entity, String.class);		
 		
		return new ModelAndView("redirect:" + "/traveller/flights/" + flightId);
	}
	

	@RequestMapping(value = "/admin/requests/index", method = RequestMethod.GET)
	public String requestsIndex(Model model)
	{
		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		
		headers.setBearerAuth(authService.getToken());
		
		model.addAttribute("username", authService.getUsername());
		
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		ResponseEntity<List> response = restTemplate.exchange(APIUtil.CANCEL_REQUESTS_LIST, HttpMethod.GET, entity, List.class);
		
		List<CancelBooking> bookingsList = response.getBody();
		
		model.addAttribute("bookingsList", bookingsList);
		model.addAttribute("username", authService.getUsername());
 		
		return REQUESTS_INDEX_HTML;
	}


	@RequestMapping(value = "/admin/request/decline/flight/{flightId}/user/{userId}", method = RequestMethod.GET)
	public String declineRequest(Model model, @PathVariable String flightId, @PathVariable String userId)
	{		
		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		
		headers.setBearerAuth(authService.getToken());
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		ResponseEntity<CancelBooking> res = restTemplate.exchange(APIUtil.GET_CANCEL_BOOKING_REQUEST(flightId, userId), HttpMethod.GET, entity, CancelBooking.class);
		
		CancelBooking booking = res.getBody();
		
		model.addAttribute("flightId", flightId);
		model.addAttribute("userId", userId);
		model.addAttribute("booking", booking);
		model.addAttribute("dr", new DeclineRequest());
		
		return DECLINE_HTML;
	}


	@RequestMapping(value = "/admin/request/decline/submit", method = RequestMethod.POST)
	public ModelAndView declineSubmit(@ModelAttribute("decline") DeclineRequest decline, Model model)
	{
		if (!authService.isAdmin()) {
			return new ModelAndView("redirect:" + "/login");
		}
		
		if(decline.getReason() == ""  || decline.getReason() == null) {
						
			return new ModelAndView("redirect:" + "/admin/requests/index");
		}
		
		headers.setBearerAuth(authService.getToken());
		
		model.addAttribute("username", authService.getUsername());
		
		HttpEntity<DeclineRequest> entity = new HttpEntity<DeclineRequest>(decline, headers);
		
		CancelBooking response = restTemplate.postForObject(APIUtil.DECLINE_CANCEL_REQUEST, entity, CancelBooking.class);		
		
		return new ModelAndView("redirect:" + "/admin/requests/index");
	}
	

	
	@RequestMapping(value = "/admin/request/approve/flight/{flightId}/user/{userId}", method = RequestMethod.GET)
	public ModelAndView approveRequest(Model model, @PathVariable String flightId, @PathVariable String userId)
	{
		if (!authService.isAdmin()) {
			return new ModelAndView("redirect:" + "/admin/requests/index");
		}
		
		headers.setBearerAuth(authService.getToken());
		
		DeclineRequest data = new DeclineRequest();
		data.setFlightId(flightId);
		data.setUserId(userId);

		HttpEntity<DeclineRequest> entity = new HttpEntity<DeclineRequest>(data, headers);
		
//		ResponseEntity<CancelBooking> res = restTemplate.exchange(APIUtil.GET_CANCEL_BOOKING_REQUEST(flightId, userId), HttpMethod.GET, entity, CancelBooking.class);
//		
//		CancelBooking booking = res.getBody();

		restTemplate.exchange(APIUtil.APPROVE_CANCEL_REQUEST, HttpMethod.POST, entity, String.class);


		return new ModelAndView("redirect:" + "/admin/requests/index");
	}

}
