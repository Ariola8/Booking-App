package com.flight.booking.controller.rest;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.booking.dto.DeclineRequest;
import com.flight.booking.entity.CancelBooking;
import com.flight.booking.entity.Flight;
import com.flight.booking.entity.User;
import com.flight.booking.service.CancelBookingService;
import com.flight.booking.service.FlightService;
import com.flight.booking.service.UserService;

@RestController
@RequestMapping("/api/v1")
public class BookingController {

	@Autowired
	private CancelBookingService bookingService;
	

	@Autowired
	private UserService userService;

	@Autowired
	private FlightService flightService;

	@GetMapping("/booking/cancel/flight/{flightId}/user/{userId}")
	public void cancelBookingRequest(@PathVariable String flightId, @PathVariable String userId)
	{
		bookingService.cancelRequest(Long.parseLong(flightId), Long.parseLong(userId));
	}
	

	@GetMapping("/get/cancel/request/flight/{flightId}/user/{userId}")
	public ResponseEntity<CancelBooking> getCancelRequests(@PathVariable String flightId, @PathVariable String userId)
	{
		try {
			CancelBooking res = bookingService.getByCancelBookingRequest(Long.parseLong(flightId), Long.parseLong(userId)); 
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) { 
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	

	@GetMapping("/requests/index")
	public List<CancelBooking> getRequestsList()
	{
		return bookingService.getCancelBookings();
		
	}
	

	
	@PostMapping("/requests/decline")
	public ResponseEntity<CancelBooking> requestDecline(@RequestBody DeclineRequest data)
	{		
		try {

			CancelBooking res = bookingService.getByCancelBookingRequest(Long.parseLong(data.getFlightId()), Long.parseLong(data.getUserId()));
			res.setReason(data.getReason());
			res.setIsApproved(-1);
			res = bookingService.update(res);
			 
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) { 
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@PostMapping("/requests/approve")
	public ResponseEntity<HttpStatus> deleteCancelRequest(@RequestBody DeclineRequest data)
	{		
		try {
			CancelBooking res = bookingService.getByCancelBookingRequest(Long.parseLong(data.getFlightId()), Long.parseLong(data.getUserId()));
			bookingService.deleteUser(res.getId());
			 		
			
			Flight flight = flightService.getFlight(Long.parseLong(data.getFlightId()));
			
			Set<User> bookings = new HashSet<>();
			
			for(User user: flight.getBookings()) {
				if(user.getId() != Long.parseLong(data.getUserId())) {
					bookings.add(user);
				}
			}
			
			flight.setBookings(bookings);
			
			flightService.updateFlight(flight);

			 
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) { 
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
}
