package com.flight.booking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.flight.booking.entity.CancelBooking;
import com.flight.booking.entity.User;


public interface CancelBookingDao extends JpaRepository<CancelBooking, Long>{


	public List<CancelBooking> findByFlightIdAndUserId(Long flightId, Long userId);	
 
	@Query(
			  value = "SELECT * FROM cancel_booking u WHERE u.flight_id = ?1 AND u.user_id = ?2", 
			  nativeQuery = true)
	public CancelBooking getByCancelBookingRequest(Long flightId, Long userId);	
	 

}
