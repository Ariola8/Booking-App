package com.flight.booking.controller;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.flight.booking.entity.Flight;
import com.flight.booking.service.APIUtil;
import com.flight.booking.service.AuthService;
import com.flight.booking.service.FlightService;

import jakarta.validation.Valid;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

@Controller
@RequestMapping("/admin")
public class AdminFlightController {


	private static final String LOGIN_HTML = "login.html";
	private static final String ADMIN_FLIGHTS_EDIT_HTML = "admin/flights/edit.html";
	private static final String ADMIN_FLIGHTS_CREATE_HTML = "admin/flights/create.html";
	private static final String ADMIN_FLIGHTS_SHOW_HTML = "admin/flights/show.html";
	private static final String ADMIN_FLIGHTS_INDEX_HTML = "admin/flights/index.html";
	
	
	@Autowired
	private FlightService flightService;
	
	@Autowired
	private AuthService authService;
	
	private RestTemplate restTemplate;	

	private HttpHeaders headers;
	
	AdminFlightController()
	{
		restTemplate = new RestTemplate();
		headers = new HttpHeaders();
	}
	

	@RequestMapping(value = "/flights", method = RequestMethod.GET)
	public String flights(Model model, @RequestParam("page") Optional<Integer> page,
			@RequestParam("size") Optional<Integer> size) {
		
		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		headers.setBearerAuth(authService.getToken());		

		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<List> response = restTemplate.exchange(APIUtil.FLIGHTS, HttpMethod.GET, entity, List.class);
		
		List<Flight> flightsList = response.getBody();

		model.addAttribute("noOfFlights", flightsList.size());

		paginate(model, page, size, flightsList);

		model.addAttribute("username", authService.getUsername());
		
		return ADMIN_FLIGHTS_INDEX_HTML;
	}

	private void paginate(Model model, Optional<Integer> page, Optional<Integer> size, List<Flight> flightsList) {

		int currentPage = page.orElse(1);
		int pageSize = size.orElse(5);

		Page<Flight> flights = flightService.findPaginated(PageRequest.of(currentPage - 1, pageSize), flightsList);

		model.addAttribute("flights", flights);

		int totalPages = flights.getTotalPages();
		
		if (totalPages > 0) {
			
			List<Integer> pageNumbers = IntStream.rangeClosed(1, totalPages).boxed().collect(Collectors.toList());
			
			model.addAttribute("pageNumbers", pageNumbers);

			int counter = pageSize * (currentPage - 1);

			model.addAttribute("counter", counter);

		}
	}

	
	
	@RequestMapping(value = "/flights/{flightId}", method = RequestMethod.GET)
	public String getFlight(Model model, @PathVariable String flightId) {
		
		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		
		headers.setBearerAuth(authService.getToken());
		
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);		

		ResponseEntity<Flight> response = restTemplate.exchange(APIUtil.FLIGHT(flightId), HttpMethod.GET, entity, Flight.class);
		
		Flight flight = response.getBody();

		model.addAttribute("flight", flight);

		model.addAttribute("username", authService.getUsername());
		
		return ADMIN_FLIGHTS_SHOW_HTML;
	}

	@RequestMapping(value = "/flights/create", method = RequestMethod.GET)
	public String create(Model model) {
		
		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		headers.setBearerAuth(authService.getToken());
				
		model.addAttribute("flight", new Flight());

		model.addAttribute("username", authService.getUsername());
		
		return ADMIN_FLIGHTS_CREATE_HTML;
	}

	@RequestMapping(value = "/flights/create", method = RequestMethod.POST)
	public String save(@Valid @ModelAttribute("flight") Flight flight, BindingResult result, Model model) {
		
		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		headers.setBearerAuth(authService.getToken());
		

		try {

			if (result.hasErrors()) {
				model.addAttribute("flight", flight);
				return ADMIN_FLIGHTS_CREATE_HTML;
			}

			
			flight = this.validateInput(flight);
			

			HttpEntity<Flight> entity = new HttpEntity<Flight>(flight, headers);

			ResponseEntity<Flight> res = restTemplate.exchange(APIUtil.FLIGHTS, HttpMethod.POST, entity, Flight.class);

			ResponseEntity<Flight> response = restTemplate.exchange(APIUtil.FLIGHT(res.getBody().getId()), HttpMethod.GET, entity, Flight.class);
			
			Flight flightRes = response.getBody();
			
			model.addAttribute("flight", flightRes);

			model.addAttribute("username", authService.getUsername());
			
			return ADMIN_FLIGHTS_SHOW_HTML;

		} catch (RestClientException e) {
			
			e.printStackTrace();
			model.addAttribute("flight", flight);

			model.addAttribute("username", authService.getUsername());
			
			return ADMIN_FLIGHTS_CREATE_HTML;
		}

	}

	private @Valid Flight validateInput(@Valid Flight flight) {
		if (flight.getEconomyClassSeats() == null)
			flight.setEconomyClassSeats(0);
		if (flight.getPremiumEconomyClassSeats() == null)
			flight.setPremiumEconomyClassSeats(0);
		if (flight.getBusinessClassSeats() == null)
			flight.setBusinessClassSeats(0);
		if (flight.getFirstClassSeats() == null)
			flight.setFirstClassSeats(0);
		return flight;
	}

	@RequestMapping(value = "/flights/{flightId}/edit", method = RequestMethod.GET)
	public String edit(@PathVariable String flightId, Model model) {
		
		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		headers.setBearerAuth(authService.getToken());


		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);		

		ResponseEntity<Flight> response = restTemplate.exchange(APIUtil.FLIGHT(flightId), HttpMethod.GET, entity, Flight.class);
		
		Flight flight = response.getBody();	
		
		model.addAttribute("flight", flight);

		model.addAttribute("username", authService.getUsername());
		
		return ADMIN_FLIGHTS_EDIT_HTML;
	}

	@RequestMapping(value = "/flights/update", method = RequestMethod.POST)
	public String udpate(@Valid @ModelAttribute Flight flight, BindingResult result, Model model) {
		
		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		headers.setBearerAuth(authService.getToken());
		
		try {

			if (result.hasErrors()) {
				model.addAttribute("flight", flight);
				model.addAttribute("username", authService.getUsername());
				return ADMIN_FLIGHTS_EDIT_HTML;
			}
			
			flight = this.validateInput(flight);
			
			HttpEntity<Flight> entity = new HttpEntity<Flight>(flight, headers);

			ResponseEntity<Flight> res = restTemplate.exchange(APIUtil.FLIGHTS, HttpMethod.PUT, entity, Flight.class);

		 	ResponseEntity<Flight> response = restTemplate.exchange(APIUtil.FLIGHT(res.getBody().getId()), HttpMethod.GET, entity, Flight.class);

			Flight flightRes = response.getBody();
			
			model.addAttribute("flight", flightRes);

			model.addAttribute("username", authService.getUsername());
			
			return ADMIN_FLIGHTS_SHOW_HTML;

		} catch (RestClientException e) {
			
			e.printStackTrace();
			model.addAttribute("flight", flight);

			model.addAttribute("username", authService.getUsername());
			return ADMIN_FLIGHTS_EDIT_HTML;
		}

	}

	@RequestMapping(value = "/flights/{flightId}/delete", method = RequestMethod.GET)
	public ModelAndView delete(@PathVariable String flightId) {
		
		if (!authService.isAdmin()) {
			return new ModelAndView("redirect:" + "/login");
		}
		headers.setBearerAuth(authService.getToken());				

		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		ResponseEntity<Flight> response = restTemplate.exchange(APIUtil.FLIGHT(flightId), HttpMethod.GET, entity, Flight.class);

		Flight flight = response.getBody();
		
		if (flight.getBookings().size() > 0)
			return new ModelAndView("redirect:" + "/admin/flights");
		
		HttpEntity<String> request = new HttpEntity<String>(flightId, headers);
		
		restTemplate.exchange(APIUtil.FLIGHT(flightId), HttpMethod.DELETE, request, String.class);

		return new ModelAndView("redirect:" + "/admin/flights");
	}

}
