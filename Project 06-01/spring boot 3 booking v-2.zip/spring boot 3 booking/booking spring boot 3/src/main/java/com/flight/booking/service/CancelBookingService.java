package com.flight.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.booking.dao.CancelBookingDao;
import com.flight.booking.dao.FlightDao;
import com.flight.booking.dao.UserDao;
import com.flight.booking.dto.DeclineRequest;
import com.flight.booking.entity.CancelBooking;
import com.flight.booking.entity.User;

@Service
public class CancelBookingService {
	
	@Autowired
	private CancelBookingDao cancelBookingDao;
	
	@Autowired
	private FlightDao flightDao;
	
	@Autowired
	private UserDao userDao;
	
	public List<CancelBooking> getCancelBookingRequests(Long flightId, Long userId)
	{
		return cancelBookingDao.findByFlightIdAndUserId(flightId, userId);
	}
	

	public CancelBooking getByCancelBookingRequest(Long flightId, Long userId)
	{
		return cancelBookingDao.getByCancelBookingRequest(flightId, userId);
	}
	
	
	
	public void cancelRequest(Long flightId, Long userId)
	{
		
		List<CancelBooking> bookingsList = cancelBookingDao.findByFlightIdAndUserId(flightId, userId);
		
		if(bookingsList.size() == 0) {
			CancelBooking booking = new CancelBooking();
			booking.setFlight(flightDao.findById(flightId).get());
			booking.setUser(userDao.findById(userId).get());
				
			cancelBookingDao.save(booking);
		}
			
		
	}


	public List<CancelBooking> getCancelBookings() {
		 return cancelBookingDao.findAll();
	}


	public CancelBooking update(CancelBooking data) {

		try {
			cancelBookingDao.save(data);
			data =cancelBookingDao.findById(data.getId()).get(); 
			return data;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	

	public void deleteUser(long id)
	{
		CancelBooking booking = cancelBookingDao.findById(id).get();
		cancelBookingDao.delete(booking);
	}

}
