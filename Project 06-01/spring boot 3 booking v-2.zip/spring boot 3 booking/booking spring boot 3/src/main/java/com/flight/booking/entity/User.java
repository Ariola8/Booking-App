package com.flight.booking.entity;



import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.util.Set;
 

import java.util.HashSet;
 


@Entity
public class User {
 
    
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
//	@Generated(strategy=GenerationType.AUTO)
	private long id;


	@NotBlank(message = "First Name is mandatory.")
	@Size(min=3, max=30)
	private String firstName;
	@Size(min=3, max=30)
	private String middleName;

	@NotBlank(message = "Last Name is mandatory.")
	@Size(min=3, max=30)
	private String lastName;


//	@NotBlank(message = "Username is mandatory.")
//	@Size(min=3, max=30)
//	private String username;


	@NotBlank(message = "Password is mandatory.")
//	@Size(min=3, max=30)
	private String password;
	
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Email(message = "Email is not valid", regexp = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$")
	@NotBlank(message = "Email is mandatory.")
	private String email;
	 
	private String phoneNumber;
	
	@Size(min=3, max=50)
	private String address;

	@NotBlank(message = "Role is mandatory.")
	private String role;
	
	@JsonIgnore
	@ManyToMany(mappedBy = "bookings")
	private Set<Flight> flights = new HashSet<>();
	 
	
	public Set<Flight> getFlights() {
		return flights;
	}

	public void setFlights(Set<Flight> flights) {
		this.flights = flights;
	}

	 

	
	
	
	public User(long id, @NotBlank(message = "First Name is mandatory.") @Size(min = 3, max = 30) String firstName,
			@Size(min = 3, max = 30) String middleName,
			@NotBlank(message = "Last Name is mandatory.") @Size(min = 3, max = 30) String lastName, 
			@NotBlank(message = "Password is mandatory.") String password,
			@Email(message = "Email is not valid", regexp = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$") @NotBlank(message = "Email is mandatory.") String email,
			String phoneNumber, @Size(min = 3, max = 50) String address,
			@NotBlank(message = "Role is mandatory.") String role, Set<Flight> flights) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName; 
		this.password = password;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.role = role;
		this.flights = flights;
	}
	
	

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
 
 
 
 
}
