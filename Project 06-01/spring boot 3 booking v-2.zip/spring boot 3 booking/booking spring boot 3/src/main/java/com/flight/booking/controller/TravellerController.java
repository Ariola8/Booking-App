package com.flight.booking.controller;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.flight.booking.entity.CancelBooking;
import com.flight.booking.entity.Flight;
import com.flight.booking.entity.User;
import com.flight.booking.service.APIUtil;
import com.flight.booking.service.AuthService;
import com.flight.booking.service.FlightService; 

@Controller
@RequestMapping("/traveller")
public class TravellerController {
 

	private static final String LOGIN_HTML = "login.html";
	private static final String TRAVELLER_FLIGHTS_SHOW_HTML = "traveller/flights/show.html";
	private static final String TRAVELLER_FLIGHTS_INDEX_HTML = "traveller/flights/index.html";
	private static final String TRAVELLER_INDEX_HTML = "traveller/index.html";


	@Autowired
	private AuthService authService;

	private RestTemplate restTemplate ;

	private HttpHeaders headers;
	
	TravellerController()
	{
		restTemplate = new RestTemplate();	
		headers = new HttpHeaders();
	}
	

	
	@Autowired
	private FlightService flightService;

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String getHome(Model model)
	{
		if (!authService.isTraveller()) {
			return LOGIN_HTML;
		}
		headers.setBearerAuth(authService.getToken());
		model.addAttribute("username", authService.getUsername());
		
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		 
		ResponseEntity<User> response = restTemplate.exchange(APIUtil.USER(authService.getId()), HttpMethod.GET, entity, User.class);
		User user = response.getBody();

		ResponseEntity<Set> responseSet = restTemplate.exchange(APIUtil.USER_BOOKINGS(authService.getId()), HttpMethod.GET, entity,
				Set.class);
		Set<Flight> flightBookings = responseSet.getBody();
		user.setFlights(flightBookings);

		model.addAttribute("user", user);

		
		return TRAVELLER_INDEX_HTML;
	}

	@RequestMapping(value = "/flights", method = RequestMethod.GET)
	public String flights(Model model, @RequestParam("page") Optional<Integer> page,
			@RequestParam("size") Optional<Integer> size) {
		
		if (!authService.isTraveller()) {
			return LOGIN_HTML;
		}
		headers.setBearerAuth(authService.getToken());	
		
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<List> response = restTemplate.exchange(APIUtil.FLIGHTS, HttpMethod.GET, entity, List.class);
		
		List<Flight> flightsList = response.getBody();

		paginateFlights(model, page, size, flightsList);

		model.addAttribute("username", authService.getUsername()); 
		return TRAVELLER_FLIGHTS_INDEX_HTML;
	}

	
	private void paginateFlights(Model model, Optional<Integer> page, Optional<Integer> size,
			List<Flight> flightsList) {
		model.addAttribute("noOfFlights", flightsList.size());

		int currentPage = page.orElse(1);
		int pageSize = size.orElse(5);

		Page<Flight> flights = flightService.findPaginated(PageRequest.of(currentPage - 1, pageSize), flightsList);

		model.addAttribute("flights", flights);

		int totalPages = flights.getTotalPages();
		if (totalPages > 0) {
			List<Integer> pageNumbers = IntStream.rangeClosed(1, totalPages).boxed().collect(Collectors.toList());
			model.addAttribute("pageNumbers", pageNumbers);

			int counter = pageSize * (currentPage - 1);

			model.addAttribute("counter", counter);

		}
	}

	
	
	@RequestMapping(value = "/flights/{flightId}", method = RequestMethod.GET)
	public String getFlight(Model model, @PathVariable String flightId) {
		
		if (!authService.isTraveller()) {
			return LOGIN_HTML;
		}
		headers.setBearerAuth(authService.getToken());
		
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);		

		ResponseEntity<Flight> response = restTemplate.exchange(APIUtil.FLIGHT(flightId), HttpMethod.GET, entity, Flight.class);
		
		Flight flight = response.getBody();
		
		boolean isCancelRequested = false;		
		
		boolean isBooked = isFlightBooked(flight);
		 
		
		if(isBooked) {

			String userId = Long.toString(authService.getId());

			ResponseEntity<CancelBooking> res = restTemplate.exchange(APIUtil.GET_CANCEL_BOOKING_REQUEST(flightId, userId), HttpMethod.GET, entity, CancelBooking.class);
			
			CancelBooking booking = res.getBody();
			
			if(booking != null) {
				isCancelRequested = true; 
				
				model.addAttribute("booking", booking);
			}
				
		}

		model.addAttribute("flight", flight);
		model.addAttribute("isBooked", isBooked);
		model.addAttribute("isCancelRequested", isCancelRequested);
		
		model.addAttribute("username", authService.getUsername()); 

		return TRAVELLER_FLIGHTS_SHOW_HTML;
	}
 

	private boolean isFlightBooked(Flight flight) {
		for(User user: flight.getBookings()) {
			if(user.getId() == authService.getId()) return true;
		}
		return false;
	}

	@RequestMapping(value = "/flights/{flightId}/booking", method = RequestMethod.GET)
	public ModelAndView bookFlight(Model model, @PathVariable String flightId) {
		
		if (!authService.isTraveller()) {
			return new ModelAndView("redirect:" + "/login");
		}
		headers.setBearerAuth(authService.getToken());
		
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		String userId = Long.toString(authService.getId());

		ResponseEntity<Flight> response = restTemplate.exchange(APIUtil.USER_FLIGHT_BOOK(flightId, userId), HttpMethod.PUT, entity, Flight.class);
		
		Flight flight = response.getBody();

		model.addAttribute("flight", flight);
		model.addAttribute("username", authService.getUsername()); 

		return new ModelAndView("redirect:" + "/traveller/index");
	}
 
	
}
