package com.flight.booking.service;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.booking.dao.UserDao;
import com.flight.booking.entity.User;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Collections; 



@Service
public class UserService {
	
	@Autowired
	private UserDao userDao;
	

    @Autowired
    private PasswordEncoder passwordEncoder;
	
	public UserService()
	{
	
	}
	
	public List<User> getUsers()
	{
		return userDao.findAll();
	}
	
	
	public User getUser(long id)
	{
		return userDao.findById(id).get();
	}
	
	public User addUser(User user)
	{
		User r = null;
		try {
			user.setPassword(passwordEncoder.encode(user.getPassword()));
			r = userDao.save(user);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return r;
	}
	
	public User updateUser(User user)
	{
		User r = null;
		try {
			user.setPassword(passwordEncoder.encode(user.getPassword()));
			r = userDao.save(user);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return r;
	}
	

	public void deleteUser(long id)
	{
		User user = userDao.findById(id).get();
		userDao.delete(user);
	}
	
	public List<User> findByEmailContaining(String email)
	{
		return userDao.findByEmailContaining(email);
	}
	
	
	 public Page<User> findPaginated(Pageable pageable, List<User> users) {
        int pageSize = pageable.getPageSize();
        int currentPage = pageable.getPageNumber();
        int startItem = currentPage * pageSize;
        List<User> list;        

        if (users.size() < startItem) {
            list = Collections.emptyList();
        } else {
            int toIndex = Math.min(startItem + pageSize, users.size());
            list = users.subList(startItem, toIndex);
        }

        Page<User> userPage = new PageImpl<User>(list, PageRequest.of(currentPage, pageSize), users.size());

        return userPage;
    }
	 
	public List<Long> getUserBookings(String userId)
	{
		return userDao.findUserBookings(Long.parseLong(userId));
	}
	
	public void deleteFromFlightUserTable(Long flightId, Long userId)
	{
		userDao.deleteFromFlightUserTable(flightId, userId);
	}
	 
}
