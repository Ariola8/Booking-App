package com.flight.booking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.flight.booking.config.UserInfoUserDetails;
import com.flight.booking.dao.UserDao;
import com.flight.booking.entity.User;


import java.util.Optional;

@Component
public class UserInfoUserDetailsService implements UserDetailsService {

    @Autowired
    private UserDao repository;
	@Autowired
	private AuthService authService;

    @Override
    public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {
        Optional<User> userInfo = repository.findByFirstName(name);
        if(userInfo!=null) {
        	authService.setId(userInfo.get().getId());
        	authService.setRole(userInfo.get().getRole());
        }
        return userInfo.map(UserInfoUserDetails::new)
                .orElseThrow(() -> new UsernameNotFoundException("user not found " + name));

    }
}
