package com.flight.booking.service;


import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.booking.dao.FlightDao;
import com.flight.booking.dao.UserDao;
import com.flight.booking.entity.Flight;
import com.flight.booking.entity.User;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;  
import java.util.Collections; 



@Service
public class FlightService {

	@Autowired
	private FlightDao flightDao;

	@Autowired
	private UserDao userDao;
	 
	public List<Flight> getFlights()
	{
		return flightDao.findAll();
	}
	
	public Flight getFlight(long id)
	{
		return flightDao.findById(id).get();
	}
	
	public Flight addFlight(Flight flight)
	{
		Flight f = null;
		try {
			f = flightDao.save(flight);
			return f;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return f;
		}
	}
	
	public Flight updateFlight(Flight flight)
	{
		Flight f = null;
		try {
			f = flightDao.save(flight);
			return f;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return f;
		}
	}
	

	public void deleteFlight(long id)
	{
		Flight flight = flightDao.findById(id).get();
		flightDao.delete(flight);
	}

	
	 public Page<Flight> findPaginated(Pageable pageable, List<Flight> flights) {
        int pageSize = pageable.getPageSize();
        int currentPage = pageable.getPageNumber();
        int startItem = currentPage * pageSize;
        List<Flight> list;
        
//        List<Flight> users = flightDao.findAll();

        if (flights.size() < startItem) {
            list = Collections.emptyList();
        } else {
            int toIndex = Math.min(startItem + pageSize, flights.size());
            list = flights.subList(startItem, toIndex);
        }

        Page<Flight> flightPage = new PageImpl<Flight>(list, PageRequest.of(currentPage, pageSize), flights.size());

        return flightPage;
    }
	 
	 
	public Flight bookFlight(Long flightId, Long userId) {
		
		Flight flight = flightDao.findById(flightId).get();
		User user = userDao.findById(userId).get();
		
		Set<User> flightBookings= flight.getBookings();
		flightBookings.add(user);
		flight.setBookings(flightBookings);

		Flight res = flightDao.save(flight);
		
		Set<Flight> userFlights = user.getFlights();
		userFlights.add(flight);
		user.setFlights(userFlights);
		user = userDao.save(user);
		
		System.out.println(user);
		
		return res;
	}
	 
	 
}
