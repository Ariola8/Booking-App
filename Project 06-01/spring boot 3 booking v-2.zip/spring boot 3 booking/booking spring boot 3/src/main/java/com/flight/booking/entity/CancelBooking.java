package com.flight.booking.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
public class CancelBooking {
	

    
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
//	@Generated(strategy=GenerationType.AUTO)
	private long id;
	
	private int isApproved;
	private String reason;
	

//    @OneToOne(cascade = CascadeType.ALL)
	@ManyToOne()
    @JoinColumn(name = "flight_id", referencedColumnName = "id")
    private Flight flight;

//	private long flightId;
    

	@ManyToOne()
//    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
	private User user;	
		 
	public CancelBooking(long id, int isApproved, String reason, Flight flight, User user) {
		super();
		this.id = id;
		this.isApproved = isApproved;
		this.reason = reason;
		this.flight = flight;
		this.user = user;
	}


	public CancelBooking() {
		super();
		// TODO Auto-generated constructor stub
	}


	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getIsApproved() {
		return isApproved;
	}
	public void setIsApproved(int isApproved) {
		this.isApproved = isApproved;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}


	public Flight getFlight() {
		return flight;
	}


	public void setFlight(Flight flight) {
		this.flight = flight;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	} 
	
	
	
	

	
	
}
