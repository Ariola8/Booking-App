package com.flight.booking.service;

public class APIUtil {

	public final static String API_URL = "http://localhost:8080/api/v1";

	public final static String USERS = "http://localhost:8080/api/v1/users";
	
	public final static String FLIGHTS = "http://localhost:8080/api/v1/flights";

	public final static String CANCEL_REQUESTS_LIST = "http://localhost:8080/api/v1/requests/index";
	
	public final static String DECLINE_CANCEL_REQUEST = "http://localhost:8080/api/v1/requests/decline";
	
	public final static String APPROVE_CANCEL_REQUEST = "http://localhost:8080/api/v1/requests/approve";
	
	

	public final static String USER(String userId)
	{
		return APIUtil.API_URL + "/users/" + userId;
	}
	
	public final static String USER(Long userId)
	{
		return APIUtil.API_URL + "/users/" + userId;
	}

	public final static String USER_BOOKINGS(String userId)
	{
		return APIUtil.API_URL + "/users/" + userId + "/bookings";
	}

	public final static String USER_BOOKINGS(Long userId)
	{
		return APIUtil.API_URL + "/users/" + userId + "/bookings";
	}
	

	public final static String USERS_EMAIL(String email)
	{
		return APIUtil.API_URL + "/users/email/" + email;
	}
	
	public final static String FLIGHT(String flightId)
	{
		return APIUtil.API_URL + "/flights/" + flightId;
	}

	public final static String FLIGHT(Long flightId)
	{
		return APIUtil.API_URL + "/flights/" + flightId;
	}

	public final static String USER_FLIGHT_BOOK(Long flightId, Long userId)
	{
		return APIUtil.API_URL + "/flights/" + flightId + "/booking/" + userId;
	}

	public final static String USER_FLIGHT_BOOK(String flightId, String userId)
	{
		return APIUtil.API_URL + "/flights/" + flightId + "/booking/" + userId;
	}
	

	public final static String BOOKING_CANCEL_REQUEST(String flightId, String userId)
	{
		return APIUtil.API_URL + "/booking/cancel/flight/" + flightId + "/user/" + userId;
	}

	public final static String BOOKING_CANCEL_REQUEST(Long flightId, Long userId)
	{
		return APIUtil.API_URL + "/booking/cancel/flight/" + flightId + "/user/" + userId;
	}

	public final static String GET_CANCEL_BOOKING_REQUESTS_LIST(Long flightId, Long userId)
	{
		return APIUtil.API_URL + "/getbooking/cancel/requests/flight/" + flightId + "/user/" + userId;
	}

	
	public final static String GET_CANCEL_BOOKING_REQUESTS_LIST(String flightId, String userId)
	{
		return APIUtil.API_URL + "/getbooking/cancel/requests/flight/" + flightId + "/user/" + userId;
	}
	

	public final static String GET_CANCEL_BOOKING_REQUEST(String flightId, String userId)
	{
		return APIUtil.API_URL + "/get/cancel/request/flight/" + flightId + "/user/" + userId;
	}
	
	public final static String GET_CANCEL_BOOKING_REQUEST(Long flightId, Long userId)
	{
		return APIUtil.API_URL + "/get/cancel/request/flight/" + flightId + "/user/" + userId;
	}
	
	
}
