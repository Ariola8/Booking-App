package com.flight.booking.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

@Component
public class AuthService {

	private Long id;
	private String username;
	private String password;
	private String role;
	private String token;
	private boolean authenticated;
	
	public boolean isAdmin()
	{
		return authenticated && (role.equals("Admin"));
	}

	public boolean isTraveller()
	{
		return authenticated && (role.equals("Traveller"));
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void setAuthenticated(boolean authenticated) {
		this.authenticated = authenticated;
	}

	public String getUsername() {
		this.readFile();
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		this.readFile();
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getToken() {
		this.readFile();
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public boolean isAuthenticated() {
		return this.authenticated;
	}

	public void logout() {
		System.out.println("Logout Successfull");
		this.authenticated = false;
	}

	public void save(String username, String password, String token) {
		try {
			File path = new File("token.txt");
			FileWriter wr = new FileWriter(path);
			wr.write(username + "\n" + password + "\n" + token);
			wr.flush();
			wr.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

		this.username = username;
		this.password = password;
		this.token = token;
		this.authenticated = true;

	}

	private void readFile() {
//		BufferedReader reader;
//		try {
//			reader = new BufferedReader(new FileReader("token.txt"));
//			this.username = reader.readLine();
//			this.password = reader.readLine();
//			this.token = reader.readLine();
//			reader.close();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
	}

}
