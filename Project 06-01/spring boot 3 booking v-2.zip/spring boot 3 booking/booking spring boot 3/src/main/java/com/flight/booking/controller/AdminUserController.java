package com.flight.booking.controller;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import com.flight.booking.entity.Flight;
import com.flight.booking.entity.User;
import com.flight.booking.service.APIUtil;
import com.flight.booking.service.AuthService;
import com.flight.booking.service.UserService;
import jakarta.validation.Valid;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

@Controller
@RequestMapping("/admin")
public class AdminUserController {

	private static final String LOGIN_HTML = "login.html";
	private static final String ADMIN_USERS_INDEX_HTML = "admin/users/index.html";
	private static final String ADMIN_USERS_SHOW_HTML = "admin/users/show.html";
	private static final String ADMIN_USERS_CREATE_HTML = "admin/users/create.html";
	private static final String ADMIN_USERS_EDIT_HTML = "admin/users/edit.html";
	private static final String ADMIN_USERS_SEARCH_HTML = "admin/users/search.html";

	@Autowired
	private UserService userService;

	@Autowired
	private AuthService authService;

	private RestTemplate restTemplate;

	private HttpHeaders headers;

	AdminUserController() {
		restTemplate = new RestTemplate();
		headers = new HttpHeaders();

	}

	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public String uers(Model model, @RequestParam("page") Optional<Integer> page,
			@RequestParam("size") Optional<Integer> size) {

		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		headers.setBearerAuth(authService.getToken());
		
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<List> response = restTemplate.exchange(APIUtil.USERS, HttpMethod.GET, entity, List.class);

		List<User> usersList = response.getBody();

		paginate(model, page, size, usersList);

		model.addAttribute("username", authService.getUsername());

		return ADMIN_USERS_INDEX_HTML;
	}

	private void paginate(Model model, Optional<Integer> page, Optional<Integer> size, List<User> usersList) {
		int currentPage = page.orElse(1);

		int pageSize = size.orElse(5);

		Page<User> users = userService.findPaginated(PageRequest.of(currentPage - 1, pageSize), usersList);

		model.addAttribute("users", users);
		model.addAttribute("noOfUsers", usersList.size());

		int totalPages = users.getTotalPages();
		if (totalPages > 0) {
			List<Integer> pageNumbers = IntStream.rangeClosed(1, totalPages).boxed().collect(Collectors.toList());
			model.addAttribute("pageNumbers", pageNumbers);
			int counter = pageSize * (currentPage - 1);
			model.addAttribute("counter", counter);
		}
	}

	@RequestMapping(value = "/users/{userId}", method = RequestMethod.GET)
	public String getUser(Model model, @PathVariable String userId) {

		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		model.addAttribute("username", authService.getUsername());

		headers.setBearerAuth(authService.getToken());
		
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<User> response = restTemplate.exchange(APIUtil.USER(userId), HttpMethod.GET, entity, User.class);
		User user = response.getBody();

		ResponseEntity<Set> responseSet = restTemplate.exchange(APIUtil.USER_BOOKINGS(userId), HttpMethod.GET, entity,
				Set.class);
		Set<Flight> flightBookings = responseSet.getBody();
		user.setFlights(flightBookings);

		model.addAttribute("user", user);

		return ADMIN_USERS_SHOW_HTML;
	}

	@RequestMapping(value = "/users/create", method = RequestMethod.GET)
	public String create(Model model) {

		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		model.addAttribute("username", authService.getUsername());

		model.addAttribute("user", new User());
		return ADMIN_USERS_CREATE_HTML;
	}

	@RequestMapping(value = "/users/create", method = RequestMethod.POST)
	public String save(@Valid @ModelAttribute("user") User user, BindingResult result, Model model) {

		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		model.addAttribute("username", authService.getUsername());

		try {
			if (result.hasErrors()) {
				model.addAttribute("user", user);
				return ADMIN_USERS_CREATE_HTML;
			}

			headers.setBearerAuth(authService.getToken());
			HttpEntity<User> entity = new HttpEntity<User>(user, headers);
			User userRes = restTemplate.postForObject(APIUtil.USERS, entity, User.class);

			ResponseEntity<User> response = restTemplate.exchange(APIUtil.USER(userRes.getId()), HttpMethod.GET, entity,
					User.class);
			User newUser = response.getBody();

			model.addAttribute("user", newUser);
			return ADMIN_USERS_SHOW_HTML;

		} catch (Exception e) {

			e.printStackTrace();
			model.addAttribute("user", user);

			return ADMIN_USERS_CREATE_HTML;
		}


	}

	@RequestMapping(value = "/users/{userId}/edit", method = RequestMethod.GET)
	public String edit(@PathVariable String userId, Model model) {

		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		model.addAttribute("username", authService.getUsername());

		headers.setBearerAuth(authService.getToken());
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<User> response = restTemplate.exchange(APIUtil.USER(userId), HttpMethod.GET, entity, User.class);
		User user = response.getBody();

		model.addAttribute("user", user);

		return ADMIN_USERS_EDIT_HTML;
	}

	@RequestMapping(value = "/users/update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("user") User user, BindingResult result, Model model) {

		if (!authService.isAdmin()) {
			return LOGIN_HTML;
		}
		model.addAttribute("username", authService.getUsername());

		try {

			if (result.hasErrors()) {
				model.addAttribute("user", user);
				return ADMIN_USERS_EDIT_HTML;
			}

			headers.setBearerAuth(authService.getToken());
			HttpEntity<User> entity = new HttpEntity<User>(user, headers);
			User userRes = restTemplate.postForObject(APIUtil.USERS, entity, User.class);

			ResponseEntity<User> response = restTemplate.exchange(APIUtil.USER(userRes.getId()), HttpMethod.GET, entity,
					User.class);
			User newUser = response.getBody();

			model.addAttribute("user", newUser);
			return ADMIN_USERS_SHOW_HTML;

		} catch (RestClientException e) {

			e.printStackTrace();
			model.addAttribute("user", user);
			return ADMIN_USERS_EDIT_HTML;
		}

	}

	@RequestMapping(value = "/users/{userId}/delete", method = RequestMethod.GET)
	public ModelAndView delete(@PathVariable String userId) {

		if (!authService.isAdmin()) {
			return new ModelAndView("redirect:" + "/login");
		}

		headers.setBearerAuth(authService.getToken());
		
		HttpEntity<String> request = new HttpEntity<String>(userId, headers);

		restTemplate.exchange(APIUtil.USER(userId), HttpMethod.DELETE, request, String.class);

		return new ModelAndView("redirect:" + "/admin/users");
	}

	@RequestMapping(value = "/users/search/{email}", method = RequestMethod.GET)
	public String getUserByEmail(Model model, @PathVariable String email) {

		headers.setBearerAuth(authService.getToken());
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<List> response = restTemplate.exchange(APIUtil.USERS_EMAIL(email), HttpMethod.GET, entity,
				List.class);
		List<User> users = response.getBody();

		model.addAttribute("users", users);
		model.addAttribute("username", authService.getUsername());

		return ADMIN_USERS_SEARCH_HTML;
	}

}
