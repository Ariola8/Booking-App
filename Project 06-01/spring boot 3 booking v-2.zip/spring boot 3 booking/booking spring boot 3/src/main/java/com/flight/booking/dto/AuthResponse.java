package com.flight.booking.dto;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;

public class AuthResponse {

	private HttpStatus statusCode;
	private boolean isValid;
	private String message;
	private String token;
	private String user;
	
	public HttpStatus getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}
	public boolean isValid() {
		return isValid;
	}
	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public AuthResponse(HttpStatus statusCode, boolean isValid, String message, String token) {
		super();
		this.statusCode = statusCode;
		this.isValid = isValid;
		this.message = message;
		this.token = token;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public AuthResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
